clc;
clear;
global T theta nu dx dt alp KMAX Tol;
T=4;
theta=1/2;
dx=1/64;
dt=dx;
nu=1e-4;
KMAX=20;
Tol=1e-12;
alp=1e-2;
Nt=T/dt;
if theta~=1 && theta~=0.5
    fprintf('Wrong: theta must be 1 or 0.5......!\n');
    return;
end
x=(-1:dx:1)';
U0=exp(-30*x.^2);
Nx=length(x);
Ix=speye(Nx);
A1=spdiags([-ones(Nx,1),2*ones(Nx,1),-ones(Nx,1)]/dx^2,[-1,0,1],Nx,Nx);
A2=spdiags([-ones(Nx,1),zeros(Nx,1),ones(Nx,1)]/(2*dx),[-1,0,1],Nx,Nx);
A1(1,Nx)=-1/dx^2;
A1(Nx,1)=A1(1,Nx);
A2(1,Nx)=-1/(2*dx);
A2(Nx,1)=-A2(1,Nx);
A=nu*A1+A2;
It=speye(Nt);

 %%% U_sbs:  reference solution computed step-by-step
U_sbs=zeros(Nx,Nt+1);
U_sbs(:,1)=U0;
Q=((Ix+dt*theta*A)\(Ix-dt*(1-theta)*A));
for n=1:Nt
    U_sbs(:,n+1)=Q*U_sbs(:,n);
end
Error_Iter=[0];
%-------------------------------------------------------
Gam=alp.^((0:Nt-1)'/Nt);
invGam=alp.^((0:-1:1-Nt)'/(Nt));  
c1=[1;-1;zeros(Nt-2,1)]/dt;
c2=[theta;1-theta;zeros(Nt-2,1)];
D1=fft(Gam.*c1);   
D2=fft(Gam.*c2);  
Uk=random('unif',-20,20,Nx,Nt);
Error_Iter(1)=max(max(abs(Uk-U_sbs(:,2:Nt+1))));
fprintf('ParaDIAG2: the initial error is  %2.15f\n',Error_Iter(1));
k=0;
for k=1:KMAX
    bkm1=[(Ix/dt-(1-theta)*A)*(U0-alp*Uk(:,Nt));zeros((Nt-1)*Nx,1)];
    bkm1=reshape(bkm1,Nx,Nt);
    sol_stepA=fft(Gam.*(bkm1.')).';
    sol_stepB=zeros(Nx,Nt);
    for n=1:Nt 
            sol_stepB(:,n)=(((D1(n))*Ix+D2(n)*A)\sol_stepA(:,n));
    end 
    Uk=(invGam.*ifft(sol_stepB.')).';
    Error_Iter(k+1)=max(max(abs(Uk-U_sbs(:,2:Nt+1))));
    fprintf('ParaDIAG2: the error at %d-th iteration is  %2.15f\n',k, Error_Iter(k+1));
    if(Error_Iter(k+1)<=Tol)
        break;
    end
end
% U_ParaDIAG2=[U0,Uk];
% mesh(0:dt:T,x,U_ParaDIAG2);shg
% set(gca,'fontname','Times New Roman','fontsize',13);
% xlabel('time: t','fontname','Times New Roman','fontsize',20);
% ylabel('space: x','fontname','Times New Roman','fontsize',20);
% if KMAX==0
%     zlabel('$\mathbf{u}^0_{\rm ParaDIAG2}$','interpreter','latex','fontsize',23);
%     title('initial guess','fontname','Times New Roman','fontsize',20);
% else
%     zlabel('$\mathbf{u}^k_{\rm ParaDIAG2}$','interpreter','latex','fontsize',23);
%     title(['After $k=$',num2str(k),' iterations'],'interpreter','latex','fontsize',22);
% end

semilogy(0:k,Error_Iter(1:k+1),'r-.o','linewidth',1,'markersize',8);shg;
set(gca,'fontname','Times New Roman','fontsize',12);
if(theta==0.5)
    title('Trapezoidal rule','fontname','Times New Roman','fontsize',20);
else
    title('Backward-Euler','fontname','Times New Roman','fontsize',20);
end
xlabel('Iteration Number: $k$','interpreter','latex','fontname','Times New Roman','fontsize',20);
ylabel('Maximal error at each iteration','fontname','Times New Roman','fontsize',20);
xlim([0,k]);
ylim([Tol,max(Error_Iter)]);
