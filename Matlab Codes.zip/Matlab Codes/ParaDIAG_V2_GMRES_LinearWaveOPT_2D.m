%function ParaDIAG_LinearWaveOPT_2D()
%2D case,  
clear
global gamma Lh Ia Ib Pre lam  dS bD D2 Ix dSinv Lh_C I0
maxL=7;  tol=1e-7;maxit=20;
 
T=2; %gamma=1e-2;
for gamma=10.^[-2:-2:-10]
    fprintf('==============Gamma [%e]=============\n',gamma);
    y_sol=@(x1,x2,t)  exp(t).*sin(pi*x1).*sin(pi*x2);
    y_t1=@(x1,x2) sin(pi*x1).*sin(pi*x2);
    p_sol=@(x1,x2,t)  (t-T).^2.*sin(pi*x1).*sin(pi*x2);
    f=@(x1,x2,t) (1+2*pi^2)*y_sol(x1,x2,t)-p_sol(x1,x2,t)/gamma;
    yd=@(x1,x2,t) 2*sin(pi*x1).*sin(pi*x2)+2*pi^2*p_sol(x1,x2,t)+y_sol(x1,x2,t);
    
    nxlist=2.^(3:maxL);%nx=ny
    ntlist=2.^(3:maxL)+1;
    levmax=length(nxlist);
    
    y_err_0=0;p_err_0=0;    
    for s=1:levmax
        nx=nxlist(s); nt=ntlist(s);
        m=nx-1;
        dt=T/nt; h=1/nx;
        [Xint,Yint,Tgd] = meshgrid(h:h:1-h,h:h:1-h,0:dt:T); %inner grid points
        %construct target yd, exact y, exact p, independent of scheme
        yd_h=yd(Xint,Yint,Tgd);
        ysol=y_sol(Xint,Yint,Tgd);
        psol=p_sol(Xint,Yint,Tgd);
        f_h=f(Xint,Yint,Tgd);        
        L=-(1/h^2)*gallery('poisson',m); %laplacian \Delta
        
        b_y=f_h;      b_p=yd_h;
        Ly0=reshape(L*reshape(ysol(:,:,1),m^2,1),m,m);
        %set right hand side according to scheme
        b_y(:,:,1)=f_h(:,:,1)/2+y_t1(Xint(:,:,1),Yint(:,:,1))/dt+ysol(:,:,1)/dt^2;
        b_y(:,:,2)=f_h(:,:,2)-ysol(:,:,1)/dt^2+0.5*Ly0;
        b_p(:,:,end)=b_p(:,:,end)/2;
        b_y=b_y(:);b_p=b_p(:);
        %Scheme based discretization
        [Lh,Ia,Ib,Lh_C]=discretizeSystem(nx,nt,T); %coefficient matrix
        I0=speye(size(Ia));
        %construct system
        L2=[Lh -Ia/sqrt(gamma);Ib/sqrt(gamma) Lh']; %rescaled
        fb=[sqrt(gamma)*b_y(1:end-m^2);b_p(m^2+1:end)];
        
        K2=[Lh_C -Ia/sqrt(gamma);Ib/sqrt(gamma) Lh_C'];
        %define preconditioner matrices
        Nt=nt;
        c1=zeros(Nt,1); c1(1:3)=[1 -2 1]; D1=fft(c1);
        c2=zeros(Nt,1); c2(1:3)=[1 0 1]; D2=fft(c2);
        Lam=D1./D2;
        R1=-(dt^2/sqrt(gamma))./(D2);
        R2=(dt^2/sqrt(gamma))./conj(D2);
        S1=0.5*(1./R1).*(Lam-conj(Lam)+sqrt((Lam-conj(Lam)).^2+4*R1.*R2));
        S2=-0.5*(1./R2).*(Lam-conj(Lam)+sqrt((Lam-conj(Lam)).^2+4*R1.*R2));
        
        dS1=spdiags(S1,0,Nt,Nt);dS2=spdiags(S2,0,Nt,Nt);
        It=speye(Nt); Ix=speye(m^2);
        dS=[It,dS2;dS1,It].';
        bD=[Lam+R1.*S1;conj(Lam)+R2.*S2];
        dSinv=([It,-dS2;0*It, It]*blkdiag(It,spdiags(1./(1-S2.*S1),0,Nt,Nt))*[It,0*It;-dS1,It]).';
        
        %%(D) Call linear solver
        tic
        Pre.TT=speye(m^2)/dt^2-0.5*L;
        Pre.nt=nt; Pre.dt=dt; Pre.h=h;
        %for fft poisson solver for solving Pre.TT
        n=m;
        lambda = (4/h^2) * (sin(((1:n)*pi) / (2*n + 2))).^2 ; %eigvalues of -Lap
        [lamx, lamy] = meshgrid(lambda,lambda);
        %for Constraint preconditioner use
        lam=(lamx+lamy);
        [z,~,~,iter]=gmres(L2,fb,[],tol,maxit,@prefun);
        tsolving=toc;
        iter=iter(end);
        %%(E) Measure errors:
        mm=m^2;
        N=mm*(nt+1);
        y0=ysol(:,:,1);pN=psol(:,:,end);
        
        x=[sqrt(gamma)*y0(:);z;pN(:)];
        y_h=x(1:N)/sqrt(gamma);     p_h=x(N+1:end);
        
        %L^infty in time and L^2 in space
        y_err_t=sqrt(h^2*sum(sum(abs(reshape(y_h,m,m,nt+1)-ysol).^2,1),2));
        p_err_t=sqrt(h^2*sum(sum(abs(reshape(p_h,m,m,nt+1)-psol).^2,1),2));
        y_err=max(y_err_t);
        p_err=max(p_err_t);
        fprintf('(%d,%d,%d)&\t %1.2e& %1.1f &\t %1.2e & %1.1f &\t %d&\t %1.1f \\\\\n',...
            nx,nx,nt,y_err,log2(y_err_0/y_err),p_err,log2(p_err_0/p_err),iter,tsolving)
        y_err_0=y_err;p_err_0=p_err;
        clear L y_h ysol p_h psol yd_h f_h b b_y b_p
    end
end

return
%plot errors
E_y=reshape(y_h-ysol,m,nt+1);
E_p=reshape(p_h-psol,m,nt+1);
tt=(0:dt:T);
subplot(2,1,1)
mesh(tt,Xint,E_y); xlabel('time');ylabel('space');
subplot(2,1,2)
mesh(tt,Xint,E_p); xlabel('time');ylabel('space');


function z=prefun(r)
global Pre dS bD D2 dSinv
N=length(r)/2;

%z2=[Lh_C -I0/sqrt(gamma);I0/sqrt(gamma) Lh_C']\r; %need faster codes

%direct implementation using fft/ifft
Nt=Pre.nt; Nx=N/Pre.nt; dt=Pre.dt;
Res=reshape(r,Nx,2*Nt);

V1a=[fft(Res(:,1:Nt).')./D2;fft(Res(:,Nt+1:end).')./conj(D2)].';
%no reshape, this can be computed in parallel, Shifted linear systems
V1=V1a*dSinv;  %use explicit inverse
for n=1:2*Nt
    %V1(:,n)=(bD(n)*Ix/dt^2-0.5*Lap)\V1(:,n); %replace by fast solver
    V1(:,n)=bdiagsolve(2*V1(:,n),2*bD(n)/dt^2); %use fast DST
end
Res2=V1*dS;
z=reshape([ifft(Res2(:,1:Nt).');ifft(Res2(:,Nt+1:end).')].',Nx*2*Nt,1);
z=real(z);
%norm(z2-z,inf)
end

function u=bdiagsolve(b,lamk)
%2D FFT
global lam
%solve Del2(u)=b
[m, n] = size(b);
% make sure we have a square grid
if (m ~= n) % assume input the vectorized
    b=full(reshape(b,sqrt(m),sqrt(m)));
    n=sqrt(m);
end
%b_bar=fast_dst(fast_dst(b).').';
b_bar=dst(dst(b).').';
% next we can solve for u_bar, vectorized version
u_bar=b_bar./(lam+lamk);
%u=fast_dst(fast_dst(u_bar).').';
u=idst(idst(u_bar).').';
if (m~=n) % to confort with input format
    u=u(:);
end
end

%module functions
function [A,B,C,K]=discretizeSystem(nx,nt,T)
%not including y(t=0) and p(t=T)
dt=T/nt;
h=1/nx; m = nx-1; %m for inner points
mm=m^2;
N=mm*(nt);%whole system size,
e_t=ones(nt,1); %e_2=ones(N_2,1);

B=blkdiag(speye(mm)/2,speye(N-mm));
C=blkdiag(speye(N-mm),speye(mm)/2);
I=speye(mm);
L=I+0.5*(dt^2/h^2)*gallery('poisson',m); % central finite difference for second derivative in space

A0=spdiags([e_t e_t],[-2 0],nt,nt);
B0=spdiags([e_t],[-1],nt,nt);
%construct circulant block of L
E=A0; E(1,end-1)=1; E(2,end)=1;
F=B0; F(1,end)=1;
A=(kron(A0,L)-kron(B0,2*I))/dt^2;
K=(kron(E,L)-kron(F,2*I))/dt^2;
end