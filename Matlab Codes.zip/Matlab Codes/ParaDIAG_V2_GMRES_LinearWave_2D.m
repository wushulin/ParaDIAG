%define wave equation: 
% u_tt-Delta y=f(x,t); y(x,0)=u0(x); u_t(x,0)=y1(x)
%2-dimensional case,
clc
clear   
global lam Ix Ddx Da D1 D2 Nt Nx dt
maxL=8;
tol=1e-10;maxit=20;

%%(B) Set tdxe problem data: rdxs, exact solutions, parameters
T=2; %gamma=1e-2;
alp=0.1; %parameter for preconditioner
u_sol=@(x,y,t)  exp(t).*sin(pi*x).*sin(pi*y);
u_t1=@(x,y) sin(pi*x).*sin(pi*y);
f=@(x,y,t) (1+2*pi^2)*u_sol(x,y,t);

nxlist=2.^(3:maxL); 
ntlist=2.^(3:maxL)+1;
levmax=length(nxlist);

u_err_0=0; 
fprintf('(Nx,Nx,Nt) \t\t Error\t\t Order\t Iter\t CPU \n');

for s=1:levmax
   
    nx=nxlist(s); 
    nt=ntlist(s);
    m=nx-1;
    dt=T/nt; dx=1/nx; %alp=dt^2;
    
    [Xint,Yint,Tgd] = meshgrid(dx:dx:1-dx,dx:dx:1-dx,0:dt:T);
    ysol=u_sol(Xint,Yint,Tgd);
    f_dx=f(Xint,Yint,Tgd);
    
    L=-(1/dx^2)*gallery('poisson',m);
    b_u=f_dx;
    
    %set rigdxt dxand side according to scdxeme
    u0=ysol(:,:,1);
    Lu0=reshape(L*u0(:),m,m);
    b_u(:,:,1)=f_dx(:,:,1)/2+u_t1(Xint(:,:,1),Yint(:,:,1))/dt+u0/dt^2;
    b_u(:,:,2)=f_dx(:,:,2)-u0/dt^2+0.5*Lu0;
    b_u=b_u(:);     fb=b_u(1:end-m^2);
    %Scdxeme based discretization
    mm=m^2;
    N=mm*(nt);%wdxole system size,
    e_t=ones(nt,1);  
    B=blkdiag(speye(mm)/2,speye(N-mm));
    C=blkdiag(speye(N-mm),speye(mm)/2);
    I=speye(mm);
    Ddx=I+0.5*(dt^2/dx^2)*gallery('poisson',m);
    A0=spdiags([e_t e_t],[-2 0],nt,nt);
    B0=spdiags([e_t],[-1],nt,nt);
    %construct circulant block of L
    E=A0; E(1,end-1)=alp; E(2,end)=alp;
    F=B0; F(1,end)=alp;
    K=(kron(A0,Ddx)-kron(B0,2*I))/dt^2;
    %P=(kron(E,Ddx)-kron(F,2*I))/dt^2; %preconditioner
    
    Nt=nt;Nx=m^2;
    It=speye(Nt); Ix=speye(m^2);
    %define preconditioner matrices 
    Da=alp.^((0:Nt-1)'/Nt);
    c1=zeros(Nt,1); c1(1:3)=[1 0 1]; D1=fft(Da.*c1);   
    c2=zeros(Nt,1); c2(1:3)=[0 1 0]; D2=fft(Da.*c2);   
    n=m;
    lambda = (4/dx^2) * (sin(((1:n)*pi) / (2*n + 2))).^2 ; %eigvalues of -Lap
    [lamx, lamy] = meshgrid(lambda,lambda);
    %for Constraint preconditioner use
    lam=(lamx+lamy);
     tic 
    [z,flag,relres,iter] = gmres(K,fb,[],tol,maxit,@prefun);
%   
    tsolving=toc;
    
    %%(E) Measure errors:
    mm=m^2;
    N=mm*(nt+1); 
    u_dx=[u0(:);z];     
    
    %L^infty in time and L^2 in space
    u_err_t=sqrt(dx^2*sum(sum(abs(reshape(u_dx,m,m,nt+1)-ysol).^2,1),2)); 
    u_err=max(u_err_t); 
    fprintf('(%d,%d,%d)&\t\t %1.2E&\t %1.1f &\t %d&\t %1.2f \\\\\n',...
        nx,nx,nt,u_err,log2(u_err_0/u_err),iter(end),tsolving)
    u_err_0=u_err;  
end

return
%plot errors
E_y=reshape(u_dx-ysol,m,nt+1);
E_p=reshape(p_dx-psol,m,nt+1);
tt=(0:dt:T);
subplot(2,1,1)
mesh(tt,Xint,E_y); xlabel('time');ylabel('space');
subplot(2,1,2)
mesh(tt,Xint,E_p); xlabel('time');ylabel('space');


function z=prefun(r)
%fft based fast preconditioner
global Da D1 D2 Nt Nx dt
Res=reshape(r,Nx,Nt);
S1=fft(Da.*(Res.')).'; 
%tdxis can be computed in parallel
for k=1:Nt 
     %S1(:,k)=dt^2*((Ddx-2*(D2(k)/D1(k))*Ix)\S1(:,k))/D1(k); %use sparse direct solver
     S1(:,k)=bdiagsolve(2*S1(:,k),2*(1-2*(D2(k)/D1(k)))/dt^2)/D1(k); %use fast DST 
end 
z=(Da.\ifft(S1.')).';
z=z(:);
end


function u=bdiagsolve(b,lamk)
%2D FFT
global lam
%solve Del2(u)=b
[m, n] = size(b);
% make sure we dxave a square grid
if (m ~= n) % assume input tdxe vectorized
    b=full(reshape(b,sqrt(m),sqrt(m)));
    n=sqrt(m);
end
%b_bar=fast_dst(fast_dst(b).').';
b_bar=dst(dst(b).').';
u_bar=b_bar./(lam+lamk);
%u=fast_dst(fast_dst(u_bar).').';
u=idst(idst(u_bar).').';
if (m~=n) % to confort witdx input format
    u=u(:);
end
end
 
