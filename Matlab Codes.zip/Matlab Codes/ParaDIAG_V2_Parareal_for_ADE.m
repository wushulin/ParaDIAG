clc;
clear;
global RK_F T nu dx dt J alp KMAX Tol;
RK_F=4;
T=4;
Dt=1/16;
J=32;
dt=Dt/J;
dx=1/64;
nu=1e-1;
KMAX=15;
Tol=1e-8;
alp=1/2;
alp=1/3;
alp=1/5;
alp=1/10;
alp=1/16;
Nt=T/Dt;
x=(-1:dx:1)';
U0=exp(-30*x.^2);
Nx=length(x);
Ix=speye(Nx);
A1=spdiags([-ones(Nx,1),2*ones(Nx,1),-ones(Nx,1)]/dx^2,[-1,0,1],Nx,Nx);
A2=spdiags([-ones(Nx,1),zeros(Nx,1),ones(Nx,1)]/(2*dx),[-1,0,1],Nx,Nx);
A1(1,Nx)=-1/dx^2;
A1(Nx,1)=A1(1,Nx);
A2(1,Nx)=-1/(2*dx);
A2(Nx,1)=-A2(1,Nx);
A=nu*A1+A2;
It=speye(Nt);

%%% U_sbs:  reference solution computed step-by-step
U_sbs=zeros(Nx,Nt+1);
U_sbs(:,1)=U0;
for n=1:Nt
        z0=U_sbs(:,n);
        for p=(n-1)*J+1:n*J
            z0=Pro_F(z0,A);
        end
        U_sbs(:,n+1)=z0; 
end
Error_Iter=[0];
%-------------------------------------------------------
GAF=alp.^((0:Nt-1)'/Nt);
invGAF=alp.^((0:-1:1-Nt)'/(Nt));  
c=[1;-1;zeros(Nt-2,1)]/Dt;
D=fft(GAF.*c);   
Uk=random('unif',-1,1,Nx,Nt+1);
Uk(:,1)=U0;
Error_Iter(1)=max(max(abs(Uk-U_sbs)));
fprintf('ParaDIAG2: the initial error is  %2.15f\n',Error_Iter(1));
k=0;
for k=1:KMAX
    tU=zeros(Nx,Nt);
    bkm1=zeros(Nx*Nt,1);
    for n=1:Nt
            z0=Uk(:,n);
            for p=(n-1)*J+1:n*J
                z0=Pro_F(z0,A);
            end
            tU(:,n)=z0; 
            if n==1
                bkm1((n-1)*Nx+1:n*Nx,1)=(Ix/Dt+A)*tU(:,n)-alp*Uk(:,Nt+1)/Dt;
            else
                bkm1((n-1)*Nx+1:n*Nx,1)=(Ix/Dt+A)*tU(:,n)-Uk(:,n)/Dt;
            end
    end
    bkm1=reshape(bkm1,Nx,Nt);
    sol_stepA=fft(GAF.*(bkm1.')).';
    sol_stepB=zeros(Nx,Nt);
    for n=1:Nt 
            sol_stepB(:,n)=(((D(n))*Ix+A)\sol_stepA(:,n));
    end 
    Uk=[U0,(invGAF.*ifft(sol_stepB.')).'];
    Error_Iter(k+1)=max(max(abs(Uk-U_sbs)));
    fprintf('ParaDIAG2: the error at %d-th iteration is  %2.15f\n',k, Error_Iter(k+1));
    if(Error_Iter(k+1)<=Tol)
        break;
    end
end
% U_ParaDIAG2=Uk;
% mesh(0:Dt:T,x,U_ParaDIAG2);shg
% set(gca,'fontname','Times New Roman','fontsize',13);
% xlabel('time: t','fontname','Times New Roman','fontsize',20);
% ylabel('space: x','fontname','Times New Roman','fontsize',20);
% if KMAX==0
%     zlabel('$\mathbf{u}^0_{\rm ParaDIAG2}$','interpreter','latex','fontsize',23);
%     title('initial guess','fontname','Times New Roman','fontsize',20);
% else
%     zlabel('$\mathbf{u}^k_{\rm ParaDIAG2}$','interpreter','latex','fontsize',23);
%     title(['After $k=$',num2str(k),' iterations'],'interpreter','latex','fontsize',22);
% end

%semilogy(0:k,Error_Iter(1:k+1),'b-.o','linewidth',1,'markersize',8);shg;
%semilogy(0:k,Error_Iter(1:k+1),'r-.s','linewidth',1,'markersize',8);shg;
%semilogy(0:k,Error_Iter(1:k+1),'k-.+','linewidth',1,'markersize',8);shg;
%semilogy(0:k,Error_Iter(1:k+1),'m-.>','linewidth',1,'markersize',8);shg;
 semilogy(0:k,Error_Iter(1:k+1),'r-','linewidth',1,'markersize',8);shg;
set(gca,'fontname','Times New Roman','fontsize',12);
xlabel('Iteration Number: $k$','interpreter','latex','fontname','Times New Roman','fontsize',20);
ylabel('Maximal error at each iteration','fontname','Times New Roman','fontsize',20);
if RK_F==2
    title('$\mathcal{F}$=2nd-order SDIRK','interpreter','latex','fontsize',22);
end
if RK_F==3
    title('$\mathcal{F}$=3rd-order Radau IIA','interpreter','latex','fontsize',22);
end
if RK_F==4
    title('$\mathcal{F}$=4th-order Lobatto','interpreter','latex','fontsize',22);
end
xlim([0,k]);
ylim([Tol,max(Error_Iter)]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function val=Pro_F(Un,A) 
    global dt;
    Nx=length(A(:,1));
    [AF,bF,~,s]=choose_F;
    Y=(speye(Nx*s,Nx*s)+dt*kron(AF,A))\kron(ones(s,1),Un);
    Sum=zeros(Nx,1);
    for js=1:s
        Sum=Sum-bF(js)*A*Y((js-1)*Nx+1:js*Nx,1);
    end
    val=Un+dt*Sum;
end

function [AF,bF,c,s]=choose_F
    global RK_F;
    if(RK_F==1)% implicit Euler
        AF=[1];
        bF=[1];
        c=[1];
        s=1;
        return;
    end
    if(RK_F==2)%DIRK of order 2
        r=(2-sqrt(2))/2;
        AF=[r,0;1-r,r];
        bF=[1-r,r];
        c=[r;1];
        s=length(bF);
        return;
    end
    if(RK_F==3) % 3rd-order Radau IIA
        AF=[5/12,-1/12;
           3/4,1/4];
        bF=[3/4,1/4];
        c=[1/3;1];
        s=length(bF);
        return;
    end
    if(RK_F==4)% 4-th order Lobatto IIIC 
        AF=[1/6,-1/3,1/6;
           1/6, 5/12, -1/12;
           1/6, 2/3, 1/6];
        c=[0;1/2;1];
        bF=[1/6, 2/3, 1/6];
        s=length(bF);
        return;
    end
end
