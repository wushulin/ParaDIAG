clc;
clear;
global T theta tau Nt nu Nx;
T=4;
theta=1/2;
tau=1.2;
Nt=64;
dx=1/64;
nu=1e-2;
if theta~=1 && theta~=0.5
    fprintf('Wrong: theta must be 1 or 0.5......!\n');
    return;
end
x=(-1:dx:1)';
U0=exp(-30*x.^2);
Nx=length(x);
Ix=speye(Nx);
A1=spdiags([-ones(Nx,1),2*ones(Nx,1),-ones(Nx,1)]/dx^2,[-1,0,1],Nx,Nx);
A2=spdiags([-ones(Nx,1),zeros(Nx,1),ones(Nx,1)]/(2*dx),[-1,0,1],Nx,Nx);
A1(1,Nx)=-1/dx^2;
A1(Nx,1)=A1(1,Nx);
A2(1,Nx)=-1/(2*dx);
A2(Nx,1)=-A2(1,Nx);
A=nu*A1+A2;
It=speye(Nt);
dtn=T*tau.^(1:Nt)/(sum(tau.^(1:Nt)));
t=zeros(1,Nt+1);
for n=2:Nt+1
    t(n)=sum(dtn(1:n-1));
end
opts = odeset('RelTol',1e-12,'AbsTol',(1e-12)*ones(Nx,1));
[t_ode45,U]= ode45(@(t,u) -A*u,[0,T], U0,opts);
U_ode45=transpose(U);
%%% U_sbs:  reference solution computed step-by-step
U_sbs=zeros(Nx,Nt+1);
U_sbs(:,1)=U0;
for n=1:Nt
    U_sbs(:,n+1)=((Ix+dtn(n)*theta*A)\(Ix-dtn(n)*(1-theta)*A))*U_sbs(:,n);
end
%%% U_ParaDIAG1: solution computed by the ParaDIAG-I algorithm 
if theta==1
    b=[(Ix/dtn(1)-(1-theta)*A)*U0;zeros((Nt-1)*Nx,1)];
    B=zeros(Nt,Nt);
    for n=1:Nt
        B(n,n)=1/dtn(n);
    end
    for n=1:Nt-1
        B(n+1,n)=-1/dtn(n+1);
    end
else
    B1=zeros(Nt,Nt);
    for n=1:Nt
        B1(n,n)=1/dtn(n);
    end
    for n=1:Nt-1
        B1(n+1,n)=-1/dtn(n+1);
    end
    B2=spdiags([(1-theta)*ones(Nt,1),theta*ones(Nt,1)],[-1,0],Nt,Nt);
    b=kron(B2\It,Ix)*[(Ix/dtn(1)-(1-theta)*A)*U0;zeros((Nt-1)*Nx,1)];
    B=B2\B1;
end
U_ParaDIAG1=zeros(Nx,Nt+1);
U_ParaDIAG1(:,1)=U0;
[V,D,invV]=getV(dtn);
sol_stepA=StepAC(invV,b);
sol_stepB=zeros(Nx*Nt,1);
for n=1:Nt
    sol_stepB((n-1)*Nx+1:n*Nx,1)=(D(n)*Ix+A)\sol_stepA((n-1)*Nx+1:n*Nx,1);
end
sol_stepC=StepAC(V,sol_stepB);
U_ParaDIAG1(:,2:Nt+1)=reshape(sol_stepC,Nx,Nt);
mesh(t_ode45(1:60:length(t_ode45)),x,U_ode45(:,1:60:length(t_ode45)));shg
set(gca,'fontname','Times New Roman','fontsize',12);
xlabel('time: t','fontname','Times New Roman','fontsize',20);
ylabel('space: x','fontname','Times New Roman','fontsize',20);
zlabel('$\mathbf{u}_{\rm ode45}$','interpreter','latex','fontsize',20);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [V,D,invV]=getV(dtn)
    global theta tau Nt;
    p=zeros(Nt-1,1);
    q=zeros(Nt-1,1);
    tD=ones(Nt,1);
    invtD=ones(Nt,1);
    if theta==0.5
        for n=1:Nt-1
            p(n)=prod((1+tau.^(1:n))./(1-tau.^(1:n)));
            q(n)=(1/tau^n)*prod((1+(tau^2)*tau.^(-n:-1))./(1-tau.^(-n:-1)));
            tD(n)=1/sqrt(1+sum(abs(p(1:Nt-n)).^2));
            invtD(n)=sqrt(1+sum(abs(p(1:Nt-n)).^2));
        end
        V=toeplitz([1;p],[1,zeros(1,Nt-1)]);
        invV=toeplitz([1;q],[1,zeros(1,Nt-1)]);
        D=2./dtn;
    end
    if theta==1
        for n=1:Nt-1
            p(n)=1/prod(1-tau.^(1:n));
            q(n)=(-1)^n*tau^((n*(n-1))/2)*p(n);
            tD(n)=1/sqrt(1+sum(abs(p(1:Nt-n)).^2));
            invtD(n)=sqrt(1+sum(abs(p(1:Nt-n)).^2));
        end
        V=toeplitz([1;p],[1,zeros(1,Nt-1)])*diag(tD);
        invV=diag(invtD)*toeplitz([1;q],[1,zeros(1,Nt-1)]);
        D=1./dtn;
    end
end
function val=StepAC(V,F)
    global Nt Nx;
    G=zeros(Nx*Nt,1);
    for j=1:Nt
        Z=zeros(Nx,1);
        for k=1:Nt
            Z=Z+V(j,k)*F((k-1)*Nx+1:k*Nx,1);
        end
       G((j-1)*Nx+1:j*Nx,1)=Z;
    end
    val=G;
end